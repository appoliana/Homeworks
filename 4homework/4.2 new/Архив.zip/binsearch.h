#pragma once

void search (int *arrayN, int n);
void print(int *arrayN, int n);

