#pragma once

// функция, которая ищет наиболее часто встречающийся элемент в массиве
int search(int *arrayN, int n);

// функция, которая печатает массив
void print(int *arrayN, int n);

