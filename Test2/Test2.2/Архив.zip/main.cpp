#include <stdio.h>
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <string>
#include "list.h"

using namespace std;

int main(int argc, char** argv) {
    FILE *outS = fopen("s.txt", "r"); 
    if (outS == nullptr) { 
        printf("File not opened");
        return 1;
    }       
    
    int value = 0;

    List* list = createList();
    List* listNew = createList();
    insert(sentinel(list), fscanf(outS, "%d", &value));
    insert(first(list), fscanf(outS, "%d", &value));
    while(!feof(outS)) {
        if (fscanf(outS, "%d", &value) != -1) 
            insert(next(first(list)), fscanf(outS, "%d", &value));
    }
    fclose(outS);
    
    //создаем новый список listNew
    //разворачиваем старый и кладем в него (?)
    //сравниваем с исходным
    
    
    
    deleteList(list);
    return 0;
}

